import { Component } from '@angular/core';
import {LoadingService} from "./services/loading.service";
import loader from "@angular-devkit/build-angular/src/webpack/plugins/single-test-transform";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  loading$ = this.loader.loading$;
  constructor(public loader: LoadingService) {
  }
  title = 'frontend';
  ngOnInit(){
  }
}
