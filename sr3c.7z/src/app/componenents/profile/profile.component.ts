import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { DownloadService } from 'src/app/services/download.service';

interface Files {
  no: number;
  xls : string;
  xlsx: string;
}

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})

export class ProfileComponent implements OnInit {

  public xls: any;
  public xlsx: any;

  constructor(private httpClient:HttpClient,private downloadServices:DownloadService) {

  }

  ngOnInit(): void {
    // this.getXls()
    // this.getXlsx()
    this.getFile()
  }

  getXls(){
    this.httpClient.get<any>('http://127.0.0.1:8000/api/listxls').subscribe(
      response => {
          console.log(response)
          this.xls = response
      }
    )
    return true;
  }

  getXlsx(){
    this.httpClient.get<any>('http://127.0.0.1:8000/api/listxlsx').subscribe(
      response => {
          console.log(response)
          this.xlsx = response
      }
    )
    return true;
  }
  getFile(){
    this.getXls()
    this.getXlsx()
    let files : Files[] = [];
    let j =0;
    let xlsx;
    for(let i =0;i<this.xls.length;i++){
      let num = i+1;
      let xls = this.xls[i];
      if(this.getFileName(this.xls[i]) == this.getFileName(this.xlsx[j])){
        xlsx = this.xlsx[j];
        j++;
      }
      else {
        let xlsx = 'No Generate Yet!!'
      }
      // write to interface
      files.push({no:num,xls:xls,xlsx:xlsx});
    }
    console.log("hi");
    return files;
  }
  generated :any = null;
  generate(fileName : string){
    this.httpClient.get<any>('http://127.0.0.1:8000/api/generate/'+fileName).subscribe(
      response => {
          this.generated = response;
          if(this.generated['success'] == true){
            window.location.reload();
          }
      }
    )
  }

  getFileName(name:string){
    var f = name.substr(0, name.lastIndexOf('.'));
    return f;
  }
  downloadxls(fileName:string){
    // this.httpClient.get<any>('http://127.0.0.1:8000/api/download/'+fileName).subscribe(
    //   // Response => {
    //   //   console.log(fileName)
    //   // }
    // )
    this.downloadServices.getXls(fileName)
        .subscribe(x => {
            // It is necessary to create a new blob object with mime-type explicitly set
            // otherwise only Chrome works like it should
            var newBlob = new Blob([x], { type: "application/vnd.ms-excel" });


            // For other browsers:
            // Create a link pointing to the ObjectURL containing the blob.
            const data = window.URL.createObjectURL(newBlob);

            var link = document.createElement('a');
            link.href = data;
            link.download = fileName;
            // this is necessary as link.click() does not work on the latest firefox
            link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));

            setTimeout(function () {
                // For Firefox it is necessary to delay revoking the ObjectURL
                window.URL.revokeObjectURL(data);
                link.remove();
            }, 100);
        });
  }

  downloadxlsx(fileName:string){
    // this.httpClient.get<any>('http://127.0.0.1:8000/api/download/'+fileName).subscribe(
    //   // Response => {
    //   //   console.log(fileName)
    //   // }
    // )
    this.downloadServices.getXlsx(fileName)
        .subscribe(x => {
            // It is necessary to create a new blob object with mime-type explicitly set
            // otherwise only Chrome works like it should
            var newBlob = new Blob([x], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });


            // For other browsers:
            // Create a link pointing to the ObjectURL containing the blob.
            const data = window.URL.createObjectURL(newBlob);

            var link = document.createElement('a');
            link.href = data;
            link.download = fileName;
            // this is necessary as link.click() does not work on the latest firefox
            link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));

            setTimeout(function () {
                // For Firefox it is necessary to delay revoking the ObjectURL
                window.URL.revokeObjectURL(data);
                link.remove();
            }, 100);
        });
  }

  selectedFile!: File;
  onFileSelected(event: any){
    this.selectedFile = event.target.files[0];
  }
  onUpload(){
    const fd = new FormData();
    fd.append('file', this.selectedFile, this.selectedFile.name)
    this.httpClient.post('http://127.0.0.1:8000/api/upload',fd)
    .subscribe( res => {
      console.log(res)
      if(res){
        window.location.reload()
      }
    })
  }

}
