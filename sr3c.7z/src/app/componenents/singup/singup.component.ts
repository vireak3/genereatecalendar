import { Component, OnInit } from '@angular/core';
import { BackendService } from '../../services/backend.service';

@Component({
  selector: 'app-singup',
  templateUrl: './singup.component.html',
  styleUrls: ['./singup.component.css']
})
export class SingupComponent implements OnInit {
  public form={
    name:null,
    email:null,
    password:null,
    password_confirmation:null,
  }
  constructor(private backend:BackendService) { }
  public errors:any =[];
  ngOnInit(): void {
  }
  public submitSignup(){
    console.log(this.form)
    return this.backend.signup(this.form).subscribe(
      data=>console.log(),
        error=>this.handleError(error)
    )
  }
  handleError(error:any){
    this.errors = error.error.errors;
  }

}
