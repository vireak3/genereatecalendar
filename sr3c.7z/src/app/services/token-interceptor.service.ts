import { Injectable } from '@angular/core';
import { HttpInterceptor,HttpHandler, HttpRequest, HttpEvent } from '@angular/common/http';
import {finalize, Observable} from 'rxjs';
import { TokenService } from './token.service'
import { Token } from '@angular/compiler';
import {LoadingService} from "./loading.service";

@Injectable({
  providedIn: 'root'
})
export class TokenInterceptorService implements HttpInterceptor{

  constructor(private token:TokenService, private loader:LoadingService) { }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    this.loader.show();
    let tokenizedReq = req.clone({
      setHeaders: {
        Authorization :'Bearer '+this.token.get()
      }
    })
    return next.handle(tokenizedReq).pipe(
      finalize(()=>{
        this.loader.hide();
      })
    );
  }

}

