import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DownloadService {

  constructor(private http:HttpClient)  { }
  getXls(filename: string): Observable<Blob> {

  //const options = { responseType: 'blob' }; there is no use of this
  let uri = 'http://10.2.7.2:84/api/downloadxls/'+filename;
  // this.http refers to HttpClient. Note here that you cannot use the generic get<Blob> as it does not compile: instead you "choose" the appropriate API in this way.
  return this.http.get(uri, { responseType: 'blob' });
  }

  getXlsx(filename: string): Observable<Blob> {

    //const options = { responseType: 'blob' }; there is no use of this
    let uri = 'http://10.2.7.2:84/api/downloadxlsx/'+filename;
    // this.http refers to HttpClient. Note here that you cannot use the generic get<Blob> as it does not compile: instead you "choose" the appropriate API in this way.
    return this.http.get(uri, { responseType: 'blob' });
    }
}
