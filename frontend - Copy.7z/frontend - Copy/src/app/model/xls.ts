export interface IXls {
  name : string;
}
