export interface IFiles{
  no : number,
  xls : string,
  xlsx : string
}
