import { Component, OnInit } from '@angular/core';
import { BackendService } from '../../services/backend.service';
import { TokenService } from '../../services/token.service';
import { AuthService } from '../../services/auth.service'
import {Params, Router} from '@angular/router';
import {ActivatedRoute} from "@angular/router";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public form = {
    email:null,
    password:null
  }
  public singupSuccess: any ={
    id:null
  };
  public state:boolean = true;
  public errors = null;
  constructor(private backend:BackendService ,private token:TokenService
    ,private router:Router, private Auth:AuthService, private activateRoute:ActivatedRoute) { }

  ngOnInit(): void {
    this.singupSuccess = this.activateRoute.snapshot.params;
    this.state =  (this.singupSuccess['id'] !="true");
  }
  submitLogin(){
    // console.warn(this.form);
    return this.backend.login(this.form).subscribe(
      data=>this.handleResponse(data),
      error=>this.handleError(error)
    );
  }
  handleError(error:any){
    this.errors = error.error.error;
    this.state = true;
  }
  handleResponse(data:any){
    console.log(data.access_token)
    this.token.handle(data.access_token);
    this.Auth.changeAuthStatus(true);
    this.router.navigateByUrl('/profile');
  }

}
