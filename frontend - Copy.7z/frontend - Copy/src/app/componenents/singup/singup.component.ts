import { Component, OnInit } from '@angular/core';
import { BackendService } from '../../services/backend.service';
import {Router} from "@angular/router"

@Component({
  selector: 'app-singup',
  templateUrl: './singup.component.html',
  styleUrls: ['./singup.component.css']
})
export class SingupComponent implements OnInit {
  public form={
    name:null,
    email:null,
    password:null,
    password_confirmation:null,
  }
  constructor(private backend:BackendService ,private router:Router) { }
  public errors:any =[];
  ngOnInit(): void {
  }
  public submitSignup(){
    console.log(this.form)
    this.backend.signup(this.form).subscribe(
      data=>console.log(),
        error=>this.handleError(error),
      () => this.success(),
    )
  }
  handleError(error:any){
    this.errors = error.error.errors;
  }

  success() {
    this.router.navigate(['/login/true'])
  }
}
