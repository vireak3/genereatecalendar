import {HttpClient} from '@angular/common/http';
import {AfterViewInit, Component, OnInit, ViewChild} from '@angular/core';
import {DownloadService} from 'src/app/services/download.service';
import {FilesListService} from 'src/app/services/files-list.service';
import {IFiles} from 'src/app/model/Files';
import {MatTableDataSource} from "@angular/material/table";
import {MatPaginator} from "@angular/material/paginator";


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})

export class ProfileComponent implements OnInit,AfterViewInit {

  public xls: any;
  public xlsx: any;
  public fileHolder: any;
  public files: IFiles[] = [];
  dataSource = new MatTableDataSource<IFiles>(this.files);


  constructor(private httpClient: HttpClient,
              private downloadServices: DownloadService, private fileList: FilesListService) {
    this.getFile()
  }

  ngOnInit(): void {
    this.getXls()
    this.getXlsx()

  }

  getXls() {
    this.httpClient.get<any>('http://10.2.7.2:84/api/listxls').subscribe(
      response => {
        console.log(response)
        this.xls = response
      }
    )
    return true;
  }

  getXlsx() {
    this.httpClient.get<any>('http://10.2.7.2:84/api/listxlsx').subscribe(
      response => {
        console.log(response)
        this.xlsx = response
      }
    )
    return true;
  }


  getFile() {
    this.fileList.getFiles().subscribe(
      data => {
        this.files = data;
        console.log(this.files)
        this.dataSource = new MatTableDataSource<IFiles>(this.files);
        this.dataSource.paginator = this.paginator;
        this.dataSource.paginator?.firstPage()
      }
    )

  }

  generated: any;

  generate(fileName: string) {
    this.httpClient.get<any>('http://10.2.7.2:84/api/generate/' + fileName).subscribe(
      response => {
        this.generated = response;
        if (this.generated['success'] == true) {
          this.getFile()
        }
        this.uploadState0 = false;
        this.uploadState1 = false;
        console.log(this.generated);
      }
    )
  }

  getFileName(name: string) {
    var f = name.substr(0, name.lastIndexOf('.'));
    return f;
  }

  downloadxls(fileName: string) {
    // this.httpClient.get<any>('http://10.2.7.2:84/api/download/'+fileName).subscribe(
    //   // Response => {
    //   //   console.log(fileName)
    //   // }
    // )
    this.downloadServices.getXls(fileName)
      .subscribe(x => {
        // It is necessary to create a new blob object with mime-type explicitly set
        // otherwise only Chrome works like it should
        var newBlob = new Blob([x], {type: "application/vnd.ms-excel"});


        // For other browsers:
        // Create a link pointing to the ObjectURL containing the blob.
        const data = window.URL.createObjectURL(newBlob);

        var link = document.createElement('a');
        link.href = data;
        link.download = fileName;
        // this is necessary as link.click() does not work on the latest firefox
        link.dispatchEvent(new MouseEvent('click', {bubbles: true, cancelable: true, view: window}));

        setTimeout(function () {
          // For Firefox it is necessary to delay revoking the ObjectURL
          window.URL.revokeObjectURL(data);
          link.remove();
        }, 100);
      });
  }

  downloadxlsx(fileName: string) {
    // this.httpClient.get<any>('http://10.2.7.2:84/api/download/'+fileName).subscribe(
    //   // Response => {
    //   //   console.log(fileName)
    //   // }
    // )
    this.downloadServices.getXlsx(fileName)
      .subscribe(x => {
        // It is necessary to create a new blob object with mime-type explicitly set
        // otherwise only Chrome works like it should
        var newBlob = new Blob([x], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});


        // For other browsers:
        // Create a link pointing to the ObjectURL containing the blob.
        const data = window.URL.createObjectURL(newBlob);

        var link = document.createElement('a');
        link.href = data;
        link.download = fileName;
        // this is necessary as link.click() does not work on the latest firefox
        link.dispatchEvent(new MouseEvent('click', {bubbles: true, cancelable: true, view: window}));

        setTimeout(function () {
          // For Firefox it is necessary to delay revoking the ObjectURL
          window.URL.revokeObjectURL(data);
          link.remove();
        }, 100);
      });
  }

  selectedFile!: File;

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
  }

  uploadState0: any;
  uploadState1: any;
  h: any;

  onUpload() {
    const fd = new FormData();
    fd.append('file', this.selectedFile, this.selectedFile.name)
    console.log(fd);
    try {
      this.httpClient.post('http://10.2.7.2:84/api/upload', fd)
        .subscribe(res => {
          console.log(res)
          this.h = res;
          if (this.h['result'] == true) {
            this.getFile()
            this.uploadState0 = true;
            this.uploadState1 = false;
            this.generated = false
          } else if (this.h['result'] == false) {
            this.uploadState1 = true;
            this.uploadState0 = false;
            this.generated = false;
          }

          console.log(this.uploadState0.result)
          this.fileHolder = '';
        })
    }catch (e) {
      console.log('upload error')
    }
  }

  displayedColumns: string[] = ['no', 'xls', 'Download', 'generate', 'No', 'xlsx', 'download'];


  @ViewChild(MatPaginator) paginator :any = MatPaginator;

  ngAfterViewInit() {
    // this.dataSource.paginator = this.paginator;
    // console.log('datasouree'+this.dataSource.data);
  }

}
