import { Component, OnInit } from '@angular/core';
import {BackendService} from "../../services/backend.service";

@Component({
  selector: 'app-forgot-psw',
  templateUrl: './forgot-psw.component.html',
  styleUrls: ['./forgot-psw.component.css']
})
export class ForgotPswComponent implements OnInit {
  public form = {
    email:null
  }
  public errors:boolean =true;
  public Message: any = true;
  constructor(private backend:BackendService) { }

  ngOnInit(): void {
  }
  submitLogin(){
     console.warn(this.form);
    return this.backend.forgotLink(this.form).subscribe(
      data=>this.handleResponse(data),
      error=>this.handleError(error)
    );
  }
  handleResponse(data:any){
    this.Message = false;
    this.errors =true;
  }
  handleError(error:any){
    this.errors = false;
    this.Message = true;
  }
}
