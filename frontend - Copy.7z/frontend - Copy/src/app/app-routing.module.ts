import {Component, NgModule} from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {LoginComponent} from './componenents/login/login.component';
import {SingupComponent} from './componenents/singup/singup.component';
import {ProfileComponent} from './componenents/profile/profile.component';
import { AfterLoginService } from './services/after-login.service'
import { BeforeLoginService } from './services/before-login.service'
import {NotfoundComponent} from "./componenents/notfound/notfound.component";
import {ForgotPswComponent} from "./componenents/forgot-psw/forgot-psw.component";


const routes: Routes = [
  {
    path:'login',
    component : LoginComponent,
    canActivate : [BeforeLoginService]
  },
  {
    path:'signup',
    component : SingupComponent,
    canActivate : [BeforeLoginService]
  },
  {
    path:'profile',
    component : ProfileComponent,
    canActivate : [AfterLoginService]
  },
  {
    path:'login/forgot',
    component : ForgotPswComponent,
  },
  {
    path:'login/:id',
    component : LoginComponent,
    canActivate : [BeforeLoginService]
  },
  {
    path:'**',
    component : NotfoundComponent,
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
