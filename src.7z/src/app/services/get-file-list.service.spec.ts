import { TestBed } from '@angular/core/testing';

import { GetFileListService } from './get-file-list.service';

describe('GetFileListService', () => {
  let service: GetFileListService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetFileListService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
